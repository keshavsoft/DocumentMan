import { jFShowToDOM } from "./Js/ShowData.js";

jFShowToDOM().then(() => {
});


