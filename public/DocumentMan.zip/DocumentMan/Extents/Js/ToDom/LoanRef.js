let ShowInDom = ({ inLoanRef }) => {

    let jVarLocalFileName = document.getElementById("InPutFileName");
    jVarLocalFileName.value = inLoanRef
};

export { ShowInDom }