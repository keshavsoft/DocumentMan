import { StartFunc as ShowTableStartFunc } from "./Js/ShowTable.js";

ShowTableStartFunc();
