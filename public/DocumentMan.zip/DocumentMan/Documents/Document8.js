import { StartFunc } from "./Js/AddListeners.js";

StartFunc();